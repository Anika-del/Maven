package com.test;

public class Demo {
  public static void main(String[] ss) {
    System.out.println("Hello World!");
  }
}